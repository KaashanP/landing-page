import React, { useState } from 'react';
import { FileText, Zap, Users, Layout, ChevronRight, BookTemplate as FileTemplate, Sparkles, Share2, Github, Twitter, Linkedin, MessageSquare, Presentation as FilePresentation, Database, Bot, Clock, CheckCircle, XCircle, ArrowRight, Timer, BarChart } from 'lucide-react';

function App() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', { name, email });
    setName('');
    setEmail('');
  };

  return (
    <div className="min-h-screen bg-dark text-gray-100">
      {/* Header Section */}
      <header className="relative neural-bg pt-16 pb-32 bg-dark-accent">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 to-purple-500/5"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-6">
              The Only Tool You Need for PRDs and Decks
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Turn Slack conversations, meeting transcripts, and internal docs into structured PRDs. Instantly transform PRDs into investor decks, strategy presentations, or any format you need. Save time and focus on what matters.
            </p>
            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
              <input
                type="text"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-dark/50 border border-gray-700 text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <input
                type="email"
                placeholder="Your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-dark/50 border border-gray-700 text-white placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <button
                type="submit"
                className="glow-button w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-500 hover:to-purple-500 transition duration-200 flex items-center justify-center space-x-2"
              >
                <span>Sign up for early access and take the manual effort out of PRDs</span>
                <ChevronRight size={20} />
              </button>
            </form>
          </div>
        </div>
      </header>

      {/* Core Features Section */}
      <section className="py-20 bg-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="p-8 bg-dark-accent rounded-xl border border-gray-800">
              <div className="flex items-center mb-6">
                <Bot className="w-8 h-8 text-blue-400 mr-4" />
                <h3 className="text-2xl font-semibold">AI-Powered PRD Creation</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <MessageSquare className="w-5 h-5 text-blue-400 mr-3 mt-1" />
                  <p>Extracts insights from Slack, meeting transcripts, and knowledge bases</p>
                </li>
                <li className="flex items-start">
                  <FileTemplate className="w-5 h-5 text-blue-400 mr-3 mt-1" />
                  <p>Customizable templates for structured PRD generation</p>
                </li>
                <li className="flex items-start">
                  <Database className="w-5 h-5 text-blue-400 mr-3 mt-1" />
                  <p>Upload and auto-populate company-specific templates</p>
                </li>
              </ul>
            </div>
            <div className="p-8 bg-dark-accent rounded-xl border border-gray-800">
              <div className="flex items-center mb-6">
                <FilePresentation className="w-8 h-8 text-purple-400 mr-4" />
                <h3 className="text-2xl font-semibold">Automated Deck Generation</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Zap className="w-5 h-5 text-purple-400 mr-3 mt-1" />
                  <p>Generate investor pitch decks from finalized PRDs</p>
                </li>
                <li className="flex items-start">
                  <Layout className="w-5 h-5 text-purple-400 mr-3 mt-1" />
                  <p>Create strategy presentations automatically</p>
                </li>
                <li className="flex items-start">
                  <Users className="w-5 h-5 text-purple-400 mr-3 mt-1" />
                  <p>Collaborate and customize generated decks in real-time</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-dark-accent neural-bg relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-24 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            How It Works
          </h2>
          
          {/* Flowchart Container */}
          <div className="relative">
            {/* Connecting Lines */}
            <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-blue-400/20 via-purple-400/20 to-blue-400/20 transform -translate-y-1/2 z-0"></div>
            
            {/* Steps */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
              {/* Step 1 */}
              <div className="relative group">
                <div className="text-center bg-dark-accent p-8 rounded-xl border border-gray-800 transition-transform duration-300 hover:-translate-y-2">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"></div>
                    <Database className="w-16 h-16 text-blue-400 mx-auto mb-6 relative z-10" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">1. Connect Sources</h3>
                  <p className="text-gray-300">Slack, meeting transcripts and internal documentation</p>
                  
                  {/* Arrow */}
                  <div className="hidden md:block absolute -right-6 top-1/2 transform -translate-y-1/2 z-20">
                    <ArrowRight className="w-8 h-8 text-purple-400" />
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="relative group">
                <div className="text-center bg-dark-accent p-8 rounded-xl border border-gray-800 transition-transform duration-300 hover:-translate-y-2">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-blue-400/10 rounded-full blur-xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"></div>
                    <Bot className="w-16 h-16 text-purple-400 mx-auto mb-6 relative z-10" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">2. Generate PRDs</h3>
                  <p className="text-gray-300">AI analyzes and creates structured PRDs from your content</p>
                  
                  {/* Arrow */}
                  <div className="hidden md:block absolute -right-6 top-1/2 transform -translate-y-1/2 z-20">
                    <ArrowRight className="w-8 h-8 text-blue-400" />
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="relative group">
                <div className="text-center bg-dark-accent p-8 rounded-xl border border-gray-800 transition-transform duration-300 hover:-translate-y-2">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"></div>
                    <FilePresentation className="w-16 h-16 text-blue-400 mx-auto mb-6 relative z-10" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">3. Create Decks</h3>
                  <p className="text-gray-300">Transform PRDs into professional presentations instantly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Time Savings Section */}
      <section className="py-20 bg-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">
            Save Hours on Documentation Every Week
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            {/* Traditional Process */}
            <div className="p-8 bg-dark-accent rounded-xl border border-gray-800">
              <div className="flex items-center mb-6">
                <XCircle className="w-8 h-8 text-red-400 mr-4" />
                <h3 className="text-2xl font-semibold">Traditional Process</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Clock className="w-5 h-5 text-red-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Manually gather insights from multiple sources</p>
                    <div className="h-2 bg-red-400/20 rounded-full">
                      <div className="h-full w-[80%] bg-red-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <Clock className="w-5 h-5 text-red-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Structure and format PRD from scratch</p>
                    <div className="h-2 bg-red-400/20 rounded-full">
                      <div className="h-full w-[70%] bg-red-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <Clock className="w-5 h-5 text-red-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Multiple revision cycles with stakeholders</p>
                    <div className="h-2 bg-red-400/20 rounded-full">
                      <div className="h-full w-[60%] bg-red-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <Clock className="w-5 h-5 text-red-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Create presentations manually for different audiences</p>
                    <div className="h-2 bg-red-400/20 rounded-full">
                      <div className="h-full w-[90%] bg-red-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
              </ul>
              <div className="mt-8 p-4 bg-red-400/10 rounded-lg">
                <p className="text-red-400 font-semibold">⏳ 5-10 hours per PRD & Deck</p>
              </div>
            </div>

            {/* AI-Powered Process */}
            <div className="p-8 bg-dark-accent rounded-xl border border-gray-800">
              <div className="flex items-center mb-6">
                <CheckCircle className="w-8 h-8 text-green-400 mr-4" />
                <h3 className="text-2xl font-semibold">With Our AI-Powered Tool</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Zap className="w-5 h-5 text-green-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Connect data sources once</p>
                    <div className="h-2 bg-green-400/20 rounded-full">
                      <div className="h-full w-[20%] bg-green-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <Bot className="w-5 h-5 text-green-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">AI auto-generates structured PRD</p>
                    <div className="h-2 bg-green-400/20 rounded-full">
                      <div className="h-full w-[15%] bg-green-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <FileTemplate className="w-5 h-5 text-green-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Quick review and approval</p>
                    <div className="h-2 bg-green-400/20 rounded-full">
                      <div className="h-full w-[10%] bg-green-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
                <li className="flex items-start">
                  <FilePresentation className="w-5 h-5 text-green-400 mr-3 mt-1" />
                  <div className="flex-1">
                    <p className="mb-2">Instant deck generation for any audience</p>
                    <div className="h-2 bg-green-400/20 rounded-full">
                      <div className="h-full w-[5%] bg-green-400 rounded-full"></div>
                    </div>
                  </div>
                </li>
              </ul>
              <div className="mt-8 p-4 bg-green-400/10 rounded-lg">
                <p className="text-green-400 font-semibold">⏳ Under 30 Minutes</p>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="max-w-3xl mx-auto text-center">
            <div className="mb-12">
              <div className="relative">
                <div className="absolute -left-12 top-1/2 -translate-y-1/2">
                  <BarChart className="w-8 h-8 text-blue-400" />
                </div>
                <div className="h-4 bg-dark-accent rounded-full overflow-hidden">
                  <div className="h-full w-[90%] bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse"></div>
                </div>
                <div className="absolute -right-12 top-1/2 -translate-y-1/2">
                  <span className="text-xl font-bold text-purple-400">90%</span>
                </div>
              </div>
              <p className="mt-4 text-2xl font-bold">Save up to 90% of time spent on documentation</p>
            </div>

            <div className="bg-dark-accent rounded-xl p-8 border border-gray-800">
              <h3 className="text-2xl font-bold mb-6">The Smartest Way to Build PRDs and Decks</h3>
              <p className="text-gray-300 mb-8">
                Product managers, founders, and teams spend countless hours reconstructing knowledge across multiple platforms just to write a PRD. Our AI-powered platform eliminates these inefficiencies by automatically extracting insights, structuring documents, and generating presentations.
              </p>
              <p className="text-xl font-semibold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                More speed. More accuracy. Less hassle.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-8">
              Take back your time. Get early access today.
            </h2>
            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
              <input
                type="text"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-white focus:border-transparent"
                required
              />
              <input
                type="email"
                placeholder="Your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:ring-2 focus:ring-white focus:border-transparent"
                required
              />
              <button
                type="submit"
                className="glow-button w-full bg-white text-blue-600 py-3 px-6 rounded-lg font-semibold hover:bg-gray-100 transition duration-200"
              >
                Join the Beta
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark-accent text-gray-400 py-12 border-t border-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-white font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Use</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>
            <div className="md:text-right">
              <h3 className="text-white font-semibold mb-4">Connect With Us</h3>
              <div className="flex space-x-4 md:justify-end">
                <a href="#" className="hover:text-white transition-colors"><Github size={24} /></a>
                <a href="#" className="hover:text-white transition-colors"><Twitter size={24} /></a>
                <a href="#" className="hover:text-white transition-colors"><Linkedin size={24} /></a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center">
            <p>&copy; 2024 Documentation Tool. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;